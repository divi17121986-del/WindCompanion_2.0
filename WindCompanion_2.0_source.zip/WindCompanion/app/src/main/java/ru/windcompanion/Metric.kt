package ru.windcompanion

import kotlin.math.roundToInt

/** Один показатель = одно осложнение. [short] — компактно для SHORT_TEXT, [full] — для LONG_TEXT и экрана. */
enum class Metric(
    val label: String,
    val shortTitle: String
) {
    TEMPERATURE("Температура", "Темп"),
    FEELS_LIKE("Ощущается", "Ощущ"),
    HUMIDITY("Влажность", "Влаж"),
    DEW_POINT("Точка росы", "Роса"),
    WIND_SPEED("Ветер", "Ветер"),
    WIND_DIR("Направление", "Напр"),
    GUSTS("Порывы", "Порывы"),
    PRESSURE("Давление", "гПа"),
    CLOUD("Облачность", "Облака"),
    PRECIP_PROB("Вероятность дождя", "Дождь"),
    PRECIP("Осадки", "Осадки"),
    UV("УФ", "УФ"),
    VISIBILITY("Видимость", "Видим"),
    THUNDER("Гроза", "Гроза"),
    SUN("Восход / закат", "Солнце"),
    DAYLIGHT("Световой день", "День");

    fun full(r: WeatherReading): String = when (this) {
        TEMPERATURE -> signedDeg(r.temperature)
        FEELS_LIKE -> signedDeg(r.feelsLike)
        HUMIDITY -> "${r.humidity}%"
        DEW_POINT -> signedDeg(r.dewPoint)
        WIND_SPEED -> "${fmt1(r.windMs)} м/с"
        WIND_DIR -> "${WindStore.compass16(r.windDir)} ${r.windDir}°"
        GUSTS -> "${fmt1(r.gustMs)} м/с"
        PRESSURE -> "${r.pressureHpa.roundToInt()} гПа"
        CLOUD -> "${r.cloud}%"
        PRECIP_PROB -> "${r.precipProb}%"
        PRECIP -> "${fmt1(r.precipMm)} мм"
        UV -> fmt1(r.uv)
        VISIBILITY -> visibility(r.visibilityM, withSpace = true)
        THUNDER -> "${r.thunderProb}%"
        SUN -> "${clockLabel(r.sunrise0)} / ${clockLabel(r.sunset0)}"
        DAYLIGHT -> hm(r.daylightSec)
    }

    /** Возвращает (текст, заголовок) для SHORT_TEXT. */
    fun short(r: WeatherReading): Pair<String, String> = when (this) {
        WIND_SPEED -> "${fmt1(r.windMs)}м/с" to shortTitle
        GUSTS -> "${fmt1(r.gustMs)}м/с" to shortTitle
        PRESSURE -> "${r.pressureHpa.roundToInt()}" to shortTitle
        PRECIP -> "${fmt1(r.precipMm)}мм" to shortTitle
        VISIBILITY -> visibility(r.visibilityM, withSpace = false) to shortTitle
        SUN -> {
            val (isRise, ts) = r.nextSunEvent()
            clockLabel(ts) to (if (isRise) "Восход" else "Закат")
        }
        else -> full(r) to shortTitle
    }

    fun placeholderFull(): String = when (this) {
        SUN -> "--:-- / --:--"
        DAYLIGHT -> "--:--"
        else -> "—"
    }

    private fun visibility(m: Double, withSpace: Boolean): String {
        val km = m / 1000.0
        val v = if (km >= 10) km.roundToInt().toString() else fmt1(km)
        return if (withSpace) "$v км" else "${v}км"
    }
}
