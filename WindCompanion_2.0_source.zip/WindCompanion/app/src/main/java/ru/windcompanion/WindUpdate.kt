package ru.windcompanion

import android.content.ComponentName
import android.content.Context
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceUpdateRequester

object WindUpdate {
    private val services: List<Class<*>> = listOf(
        TemperatureDataSourceService::class.java,
        FeelsLikeDataSourceService::class.java,
        HumidityDataSourceService::class.java,
        DewPointDataSourceService::class.java,
        WindSpeedDataSourceService::class.java,
        WindDirectionDataSourceService::class.java,
        GustsDataSourceService::class.java,
        PressureDataSourceService::class.java,
        CloudDataSourceService::class.java,
        PrecipProbDataSourceService::class.java,
        PrecipDataSourceService::class.java,
        UvDataSourceService::class.java,
        VisibilityDataSourceService::class.java,
        ThunderDataSourceService::class.java,
        SunDataSourceService::class.java,
        DaylightDataSourceService::class.java
    )

    fun requestAll(context: Context) {
        services.forEach { cls ->
            runCatching {
                ComplicationDataSourceUpdateRequester.create(context, ComponentName(context, cls)).requestUpdateAll()
            }
        }
    }
}
