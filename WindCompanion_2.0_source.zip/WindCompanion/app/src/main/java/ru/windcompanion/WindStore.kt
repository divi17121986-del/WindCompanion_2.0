package ru.windcompanion

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Все значения, приходящие одним запросом Open-Meteo. */
data class WeatherReading(
    val temperature: Double,
    val feelsLike: Double,
    val humidity: Int,
    val dewPoint: Double,
    val windMs: Double,
    val windDir: Int,
    val gustMs: Double,
    val pressureHpa: Double,
    val cloud: Int,
    val precipProb: Int,
    val precipMm: Double,
    val uv: Double,
    val visibilityM: Double,
    val thunderProb: Int,
    val sunrise0: Long,
    val sunset0: Long,
    val sunrise1: Long,
    val sunset1: Long,
    val daylightSec: Int,
    val updatedAt: Long
) {
    fun updatedLabel(): String =
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(updatedAt))

    /** Ближайшее будущее событие: пара (восход? , время). */
    fun nextSunEvent(now: Long = System.currentTimeMillis()): Pair<Boolean, Long> {
        val events = listOf(true to sunrise0, false to sunset0, true to sunrise1, false to sunset1)
        return events.firstOrNull { it.second > now } ?: (false to sunset1)
    }

    fun toJson(): String = JSONObject().apply {
        put("temperature", temperature); put("feelsLike", feelsLike)
        put("humidity", humidity); put("dewPoint", dewPoint)
        put("windMs", windMs); put("windDir", windDir); put("gustMs", gustMs)
        put("pressureHpa", pressureHpa); put("cloud", cloud)
        put("precipProb", precipProb); put("precipMm", precipMm)
        put("uv", uv); put("visibilityM", visibilityM); put("thunderProb", thunderProb)
        put("sunrise0", sunrise0); put("sunset0", sunset0)
        put("sunrise1", sunrise1); put("sunset1", sunset1)
        put("daylightSec", daylightSec); put("updatedAt", updatedAt)
    }.toString()

    companion object {
        fun fromJson(s: String): WeatherReading? = runCatching {
            val o = JSONObject(s)
            WeatherReading(
                o.getDouble("temperature"), o.getDouble("feelsLike"),
                o.getInt("humidity"), o.getDouble("dewPoint"),
                o.getDouble("windMs"), o.getInt("windDir"), o.getDouble("gustMs"),
                o.getDouble("pressureHpa"), o.getInt("cloud"),
                o.getInt("precipProb"), o.getDouble("precipMm"),
                o.getDouble("uv"), o.getDouble("visibilityM"), o.getInt("thunderProb"),
                o.getLong("sunrise0"), o.getLong("sunset0"),
                o.getLong("sunrise1"), o.getLong("sunset1"),
                o.getInt("daylightSec"), o.getLong("updatedAt")
            )
        }.getOrNull()
    }
}

object WindStore {
    private const val PREFS = "wind_data"
    const val KEY = "reading_v2"

    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun save(context: Context, reading: WeatherReading) {
        prefs(context).edit().putString(KEY, reading.toJson()).apply()
    }

    fun read(context: Context): WeatherReading? =
        prefs(context).getString(KEY, null)?.let { WeatherReading.fromJson(it) }

    fun compass16(degrees: Int): String {
        val points = arrayOf("С", "ССВ", "СВ", "ВСВ", "В", "ВЮВ", "ЮВ", "ЮЮВ",
            "Ю", "ЮЮЗ", "ЮЗ", "ЗЮЗ", "З", "ЗСЗ", "СЗ", "ССЗ")
        return points[((((degrees % 360 + 360) % 360) + 11.25) / 22.5).toInt() % 16]
    }
}

internal val RU: Locale = Locale.forLanguageTag("ru")

internal fun fmt1(d: Double): String = String.format(RU, "%.1f", d)

internal fun signedDeg(t: Double): String {
    val r = t.roundToInt()
    return if (r > 0) "+$r°" else "$r°"
}

internal fun clockLabel(ms: Long): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ms))

internal fun hm(seconds: Int): String =
    String.format(Locale.US, "%02d:%02d", seconds / 3600, (seconds % 3600) / 60)
