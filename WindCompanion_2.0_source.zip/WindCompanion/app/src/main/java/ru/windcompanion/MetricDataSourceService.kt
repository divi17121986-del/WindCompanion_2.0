package ru.windcompanion

import androidx.wear.watchface.complications.data.ComplicationData
import androidx.wear.watchface.complications.data.ComplicationType
import androidx.wear.watchface.complications.data.LongTextComplicationData
import androidx.wear.watchface.complications.data.PlainComplicationText
import androidx.wear.watchface.complications.data.ShortTextComplicationData
import androidx.wear.watchface.complications.datasource.ComplicationRequest
import androidx.wear.watchface.complications.datasource.SuspendingComplicationDataSourceService

abstract class MetricDataSourceService(private val metric: Metric) :
    SuspendingComplicationDataSourceService() {

    override suspend fun onComplicationRequest(request: ComplicationRequest): ComplicationData? {
        WindWork.start(applicationContext)
        val reading = WindStore.read(applicationContext)
        return build(reading, request.complicationType)
    }

    override fun getPreviewData(type: ComplicationType): ComplicationData? =
        build(null, type)

    private fun build(reading: WeatherReading?, type: ComplicationType): ComplicationData? {
        val description = if (reading == null) "${metric.label}: ожидание данных"
        else "${metric.label} ${metric.full(reading)}, обновлено ${reading.updatedLabel()}"
        val descText = PlainComplicationText.Builder(description).build()
        return when (type) {
            ComplicationType.SHORT_TEXT -> {
                val (text, title) = reading?.let { metric.short(it) } ?: ("—" to metric.shortTitle)
                ShortTextComplicationData.Builder(
                    PlainComplicationText.Builder(text).build(), descText
                ).setTitle(PlainComplicationText.Builder(title).build()).build()
            }
            ComplicationType.LONG_TEXT -> {
                val text = reading?.let { metric.full(it) } ?: metric.placeholderFull()
                LongTextComplicationData.Builder(
                    PlainComplicationText.Builder(text).build(), descText
                ).setTitle(PlainComplicationText.Builder(metric.label).build()).build()
            }
            else -> null
        }
    }
}
